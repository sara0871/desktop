# Activity filter for GitHub

A Chrome extension for filtering the activity feed on github.com dashboard.

![screenshot](https://user-images.githubusercontent.com/1153134/43299617-d3e58f7c-9128-11e8-91ec-a1df1eb048a1.png)

&nbsp;

### Install

- [Download from the chrome web store](https://chrome.google.com/webstore/detail/pcnaddhmngnnpookfhhamkelhhakimdg).
- [Manually load the extension](https://github.com/muan/github-gmail#the-mu-an-might-steal-all-my-data-so-i-want-to-manually-load-it-way-for-chrome).
